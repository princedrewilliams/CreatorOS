import React from 'react';
import { ChannelAnalyzer } from './components/ChannelAnalyzer';
export function App() {
  return <main className="min-h-screen w-full relative flex flex-col items-center justify-center overflow-hidden bg-[#050505] selection:bg-pink-500/30 selection:text-pink-200">
      {/* Deep Atmospheric Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[#1a0510] via-[#050505] to-[#050505] z-0" />

      {/* Animated Luminous Orbs / Waves */}
      {/* Top Right Pink Wave */}
      <div className="absolute top-[-20%] right-[-10%] w-[800px] h-[800px] rounded-full bg-pink-600/10 blur-[120px] animate-pulse mix-blend-screen" style={{
      animationDuration: '8s'
    }} />

      {/* Bottom Left Rose Wave */}
      <div className="absolute bottom-[-20%] left-[-10%] w-[900px] h-[900px] rounded-full bg-rose-600/10 blur-[120px] animate-pulse mix-blend-screen" style={{
      animationDuration: '10s'
    }} />

      {/* Center Subtle Glow */}
      <div className="absolute top-[30%] left-[50%] -translate-x-1/2 w-[600px] h-[400px] rounded-full bg-pink-500/5 blur-[100px] pointer-events-none" />

      {/* Curved Lines / Wave Patterns (SVG Overlay) */}
      <div className="absolute inset-0 z-0 opacity-30 pointer-events-none">
        <svg className="w-full h-full" viewBox="0 0 1440 900" xmlns="http://www.w3.org/2000/svg">
          <path d="M-100 600 C 200 400, 400 800, 800 200 C 1200 -400, 1600 200, 1800 800" stroke="url(#grad1)" strokeWidth="2" fill="none" className="animate-[dash_20s_linear_infinite]" strokeDasharray="10 10" />
          <path d="M-100 800 C 300 600, 500 900, 900 300 C 1300 -300, 1700 300, 1900 900" stroke="url(#grad2)" strokeWidth="1" fill="none" opacity="0.5" />
          <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgba(236, 72, 153, 0)" />
              <stop offset="50%" stopColor="rgba(236, 72, 153, 0.3)" />
              <stop offset="100%" stopColor="rgba(236, 72, 153, 0)" />
            </linearGradient>
            <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgba(244, 63, 94, 0)" />
              <stop offset="50%" stopColor="rgba(244, 63, 94, 0.2)" />
              <stop offset="100%" stopColor="rgba(244, 63, 94, 0)" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Noise Texture Overlay for Film Grain Effect */}
      <div className="absolute inset-0 opacity-[0.04] pointer-events-none z-0 mix-blend-overlay" style={{
      backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
    }} />

      {/* Content */}
      <div className="relative z-10 w-full px-4 py-8">
        <ChannelAnalyzer />
      </div>
    </main>;
}